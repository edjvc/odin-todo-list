const DOMController = {
  bindUIEvents(app) {
    document
      .querySelector('#add-project')
      ?.addEventListener('click', app.handleAddProject);
    document
      .querySelector('#add-todo')
      ?.addEventListener('click', app.handleAddTodo);
    document
      .querySelector('#show-completed')
      ?.addEventListener('click', app.handleViewCompleted);

    document.querySelector('#project-list')?.addEventListener('click', (e) => {
      if (e.target.dataset.id) {
        app.handleProjectClick(e.target.dataset.id);
      }
    });

    document.querySelector('#todo-list')?.addEventListener('click', (e) => {
      const id = e.target.closest('li')?.dataset.id;
      if (!id) return;
      if (e.target.matches('.complete-btn')) {
        app.handleCompleteClick(id);
      } else {
        app.handleTodoClick(id);
      }
    });
  },

  renderProjects(projects, activeId) {
    const list = document.querySelector('#project-list');
    list.innerHTML = '';
    projects.forEach((p) => {
      const li = document.createElement('li');
      li.textContent = p.name;
      li.dataset.id = p.id;
      if (p.id === activeId) li.style.fontWeight = 'bold';
      list.appendChild(li);
    });
  },

  renderTodos(todos) {
    const list = document.querySelector('#todo-list');
    list.innerHTML = '';
    todos.forEach((t) => {
      const li = document.createElement('li');
      li.dataset.id = t.id;
      li.innerHTML = `
        <span>${t.title}</span>
        <button class="complete-btn">${t.completed ? 'Restore' : 'Done'}</button>
      `;
      list.appendChild(li);
    });
  },

  openModal({ title, showDescription = false, onSubmit }) {
    const modal = document.querySelector('#modal');
    const form = modal.querySelector('form');
    modal.querySelector('#modal-title').textContent = title;
    form.description
      ?.closest('textarea')
      ?.classList.toggle('hidden', !showDescription);

    form.reset();
    modal.showModal();

    form.onsubmit = (e) => {
      e.preventDefault();
      const title = form.elements.title.value.trim();
      const description = form.elements.description?.value.trim() ?? '';
      const priority = form.elements.priority?.value ?? 'low';
      if (!title) return;
      modal.close();
      onSubmit?.({ title, description, priority });
    };
  },
};

export default DOMController;
