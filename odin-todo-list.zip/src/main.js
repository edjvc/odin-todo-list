import './style.css';
import appController from './appController.js';

appController.init();

// console.log();
// appController.handleAddTodo({ title: 'buy heart' });
