import './style.css';
import appController from './appController.js';

appController.init();
