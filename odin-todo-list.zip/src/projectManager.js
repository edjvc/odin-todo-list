import { Project } from './project.js';

let projects = [];
let activeProjectId = null;

const projectManager = {
  add(data) {
    const project = new Project(data);
    projects.push(project);
    return project;
  },

  edit(id, updates) {
    const project = this.getById(id);
    if (!project) return false;
    Object.assign(project, updates);
    return true;
  },

  remove(id) {
    if (!this.isDeletable(id)) return false;
    const index = projects.findIndex((p) => p.id === id);
    if (index === -1) return false;
    projects.splice(index, 1);
    if (activeProjectId === id) {
      activeProjectId = projects[0]?.id ?? null;
    }
    return true;
  },

  getById(id) {
    return projects.find((p) => p.id === id);
  },

  getAll() {
    return [...projects];
  },

  getActive() {
    return this.getById(activeProjectId);
  },

  getActiveId() {
    return activeProjectId;
  },

  setActive(id) {
    if (this.getById(id)) activeProjectId = id;
  },

  isDeletable() {
    return this.getAll().length > 1;
  },

  createDefaultProject() {
    const defaultProject = this.add({ name: 'my project' });
    this.setActive(defaultProject.id);
    return defaultProject;
  },

  load(plainObjectProjects) {
    projects = plainObjectProjects.map((obj) => new Project(obj));
    activeProjectId ||= projects[0]?.id ?? null;
    // if (!activeProjectId) {
    //   activeProjectId = projects[0]?.id ?? null;
    // }
  },

  toPlainObject() {
    return projects.map((p) => p.toPlainObject());
  },
};

export default projectManager;
