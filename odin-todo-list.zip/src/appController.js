import todoManager from './todoManager.js';
import projectManager from './projectManager.js';
import storageController from './storageController.js';
import viewState from './viewState.js';
import DOMController from './DOMController.js';

const appController = {
  init() {
    const data = storageController.load();
    if (data) {
      projectManager.load(data.projects);
      todoManager.load(data.todos);
      viewState.load(data.viewState);
    } else {
      const defaultProject = projectManager.createDefaultProject();
      viewState.setProjectView(defaultProject.id);
      this.persist();
      console.log('active project id 1:', viewState.getActiveProjectId());
    }
    DOMController.bindUIEvents(this);
    this.renderProjects();
    DOMController.renderCompleted();

    console.log(projectManager.getAll());
    console.log('active project:', projectManager.getActiveId());
    console.log('completed folder');
    this.renderProjects();
    this.renderTodos();
  },

  renderProjects() {
    DOMController.renderProjects(
      projectManager.getAll(),
      projectManager.getActiveId()
    );

    console.log(projectManager.getAll());
    console.log(projectManager.getActiveId());
  },

  renderTodos() {
    const currentView = viewState.getCurrentView();
    if (!currentView) return;
    let todos = [];
    if (currentView === 'project') {
      todos = todoManager.getByProject(viewState.getActiveProjectId());
    } else if (currentView === 'completed') {
      todos = todoManager.getCompleted();
    }
    DOMController.renderTodos(todos);

    console.log('active project id:', viewState.getActiveProjectId());
    console.log('todos list: ', todos);
  },

  handleAddTodo() {
    DOMController.openModal({
      title: 'New Task',
      showDescription: true,
      onSubmit({ title, description, priority }) {
        todoManager.add({
          title,
          description,
          priority,
          projectId: viewState.getActiveProjectId(),
        });
        this.persist();
        this.renderTodos();
      },
    });
  },

  handleEditTodo(id, updates) {
    todoManager.edit(id, updates);
    this.persist();
    this.renderTodos();
  },

  handleRemoveTodo(id) {
    todoManager.remove(id);
    this.persist();
    this.renderTodos();
  },

  handleToggleTodo(id) {
    const todo = todoManager.getById(id);
    if (!todo) return;
    todo.completed ? todoManager.restore(id) : todoManager.markComplete(id);
    this.persist();
    this.renderTodos();
  },

  // handleClearCompleted() {
  //   todoManager.clearCompleted();
  //   this.persist();
  //   this.renderTodos();
  // },

  handleAddProject() {
    DOMController.openModal({
      title: 'New Project',
      showDescription: false,
      onSubmit({ title }) {
        const newProject = projectManager.add({ name: title });
        this.handleSelectProject(newProject.id);
      },
    });
  },

  handleEditProject(id, updates) {
    projectManager.edit(id, updates);
    this.persist();
    this.renderProjects();
  },

  handleRemoveProject(id) {
    if (!projectManager.remove(id)) return;
    this.persist();
    this.renderProjects();
    this.renderTodos();
  },

  handleMoveToProject(id, newProjectId) {
    todoManager.moveToProject(id, newProjectId);
    this.persist();
    this.renderProjects();
    this.renderTodos();
  },

  handleSelectProject(id) {
    projectManager.setActive(id);
    viewState.setProjectView(id);
    this.persist();
    this.renderProjects();
    this.renderTodos();
  },

  handleClickProjectTheSecondTime(id) {
    if (id === viewState.getActiveProjectId()) {
      DOMController.showProjectModal();
    }
  },

  handleCompleteTodo(id) {
    const todo = todoManager.getById(id);
    if (!todo) return;

    if (todo.completed) {
      todo.restore();
    } else {
      todo.markComplete();
    }
    this.persist();
    this.renderProjects();
    this.renderTodos();
  },

  handleSelectCompleted() {
    viewState.setCompletedView();
    this.persist();
    this.renderProjects();
    this.renderTodos();
  },

  handleSelectTodo(id) {
    const todo = todoManager.getById(id);
    if (!todo) return;
    DOMController.showTodoModal(todo);
  },

  persist() {
    storageController.save(
      projectManager.toPlainObject(),
      todoManager.toPlainObject(),
      viewState.toPlainObject()
    );
  },

  getViewStateActive() {
    return viewState.getActiveProjectId();
  },
};

export default appController;
