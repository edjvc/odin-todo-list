import { defineConfig } from 'vite';

export default defineConfig({
  // base: '/odin-todo-list/',
});
