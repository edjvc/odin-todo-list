# vanilla-vite-template (Vanilla + Vite + ESLint + Prettier)

```bash
npm install
npm run dev
```

**After creating a new project remember to search and replace all instances of "vanilla-vite-template" with your actual project name.**
- vite.config.js
- index.html
- package.json
- src/main.js